using Terraria.ModLoader;

namespace Bannerreward
{
	public class Bannerreward : Mod
	{
	}
}