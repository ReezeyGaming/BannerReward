using IL.Terraria;
using System.CodeDom.Compiler;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Bannerreward.Items
{
	public class ItemBad : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("You are bad person");
			// DisplayName.SetDefault("YOU ARE BAD"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("BAD");
		}

		public override void SetDefaults()
		{
			item.damage = 500000;
		}

		public override void AddRecipes()
		{
	
		}
	}
}