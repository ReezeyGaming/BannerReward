using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Bannerreward.Items
{
	public class Bag42 : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Blue Armored Bones Bag");
			Tooltip.SetDefault("Loot!!!!");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.rare = 0;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player player)
		{
			player.QuickSpawnItem(ItemID.Bone, 50);
			player.QuickSpawnItem(ItemID.ArmorPolish, 1);
			player.QuickSpawnItem(ItemID.BlueBrick, 100);
			player.QuickSpawnItem(ItemID.PinkBrick, 100);
			player.QuickSpawnItem(ItemID.GreenBrick, 100);
			player.QuickSpawnItem(ItemID.GoldCoin, 10);
			player.QuickSpawnItem(ItemID.CobaltBar, 5);
			player.QuickSpawnItem(ItemID.Ectoplasm, 25);
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.BlueArmoredBonesBanner, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}