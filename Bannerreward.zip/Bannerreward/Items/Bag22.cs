using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Bannerreward.Items
{
	public class Bag22 : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Illuminant slime Bag");
			Tooltip.SetDefault("Loot!!!!");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.rare = 0;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player player)
		{
			player.QuickSpawnItem(ItemID.Gel, 50);
			player.QuickSpawnItem(ItemID.SoulofLight, 25);
			player.QuickSpawnItem(ItemID.GoldCoin, 10);
			player.QuickSpawnItem(ItemID.PearlstoneBlock, 100);
			player.QuickSpawnItem(ItemID.CrystalShard, 25);


		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.IlluminantSlimeBanner, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}