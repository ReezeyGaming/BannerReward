using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Bannerreward.Items
{
	public class Bag86 : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Eater of Souls Bag");
			Tooltip.SetDefault("Loot!!!!");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.rare = 0;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player player)
		{
			player.QuickSpawnItem(ItemID.RottenChunk, 25);
			player.QuickSpawnItem(ItemID.GoldCoin, 10);
			player.QuickSpawnItem(ItemID.Ebonwood, 100);
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.EaterofSoulsBanner, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}