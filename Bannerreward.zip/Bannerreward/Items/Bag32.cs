using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Bannerreward.Items
{
	public class Bag32 : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hell Bat Bag");
			Tooltip.SetDefault("Loot!!!!");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.rare = 0;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player player)
		{
			player.QuickSpawnItem(ItemID.MagmaStone,1);
			player.QuickSpawnItem(ItemID.Fireblossom, 20);
			player.QuickSpawnItem(ItemID.GoldCoin, 10);
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.HellbatBanner, 1);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}